#!/usr/bin/env bash
# Instala as dependências e baixa os arquivos que o DroidOS usa.
cd "$(dirname "$0")" || exit 1
mkdir -p assets third_party build

echo "==> Pacotes"
command -v g++ >/dev/null 2>&1 || pkg install -y clang
command -v curl >/dev/null 2>&1 || pkg install -y curl
if [ ! -f "$PREFIX/include/X11/Xlib.h" ] || [ ! -f "$PREFIX/include/EGL/egl.h" ]; then
  pkg install -y x11-repo
  pkg install -y libx11 xorgproto mesa
fi
command -v termux-x11 >/dev/null 2>&1 || pkg install -y termux-x11-nightly
command -v termux-volume >/dev/null 2>&1 || pkg install -y termux-api

# baixa um arquivo (ignora se já existe; descarta se veio página de erro)
dl() {
  [ -s "$2" ] && return 0
  curl -fsSL -A "Mozilla/5.0" -o "$2" "$1" || { rm -f "$2"; return 1; }
  [ "$(head -c 1 "$2")" = "<" ] && rm -f "$2"
  [ -s "$2" ]
}

echo "==> Bibliotecas (stb)"
dl https://raw.githubusercontent.com/nothings/stb/master/stb_truetype.h third_party/stb_truetype.h
dl https://raw.githubusercontent.com/nothings/stb/master/stb_image.h third_party/stb_image.h

echo "==> Imagens"
dl "https://i.postimg.cc/59PJkTpD/143-Sem-Titulo-20260530003251.png" assets/logo.png
dl "https://commons.wikimedia.org/wiki/Special:FilePath/Firefox_logo%2C_2019.svg?width=512" assets/firefox.png
if [ ! -s assets/firefox.png ]; then
  for f in "$PREFIX"/share/icons/hicolor/*/apps/firefox.png; do [ -f "$f" ] && cp "$f" assets/firefox.png; done
fi

echo "==> Fonte"
ls /system/fonts/Roboto* >/dev/null 2>&1 || dl "https://github.com/dejavu-fonts/dejavu-fonts/raw/version_2_37/ttf/DejaVuSans.ttf" assets/font.ttf

echo
[ -s third_party/stb_truetype.h ] && [ -s third_party/stb_image.h ] || echo "ATENÇÃO: faltou baixar os stb_*.h (sem internet?). Rode ./install.sh de novo."
[ -s assets/logo.png ]    || echo "Aviso: assets/logo.png não baixou. Copie sua logo para assets/logo.png (senão aparece o robô)."
[ -s assets/firefox.png ] || echo "Aviso: assets/firefox.png não baixou. Copie um firefox.png para assets/ (senão uso um desenho simples)."
echo "Pronto. Rode: ./run.sh"
