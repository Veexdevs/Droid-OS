# DroidOS

Área de trabalho em C++ (X11 + EGL/GLES3) para o **Termux:X11**.

- Barra de tarefas com logo, relógio e data
- Brilho, volume, dados móveis (2G–5G) e Wi-Fi, todos clicáveis
- Dock com o Firefox: janela que arrasta, redimensiona, minimiza e maximiza
- Fontes TrueType reais (usa a Roboto do Android)

## Instalar e rodar (Termux)

```bash
pkg install -y git
git clone https://github.com/SEU_USUARIO/droidos.git
cd droidos
./install.sh
./run.sh
```

Abra o app **Termux:X11** antes de rodar. Para atualizar depois:

```bash
cd droidos && git pull && ./run.sh
```

## Comandos

| Comando | O que faz |
| --- | --- |
| `./install.sh` | instala pacotes e baixa stb, logo, ícone do Firefox e fonte |
| `./run.sh` | compila (se o código mudou) e executa |
| `./run.sh --rebuild` | força recompilar |
| `DROIDOS_START_X11=1 ./run.sh` | também inicia o servidor `termux-x11` |

## Configuração

- **GPU / variáveis de ambiente:** crie `env.sh` na raiz (ex.: `export GALLIUM_DRIVER=zink`). Sem ele, o `run.sh` reaproveita os `export` do `~/test_local/run_engine.sh`, se existir.
- **Logo:** troque `assets/logo.png`.
- **Fonte:** coloque `assets/font.ttf` (e `assets/font-bold.ttf`) para usar outra.
- **Sinal, volume e brilho reais:** instale o app **Termux:API** e dê as permissões (localização para o sinal do celular e o nome do Wi-Fi). Sem isso os ícones mostram valores de exemplo.

## Estrutura

```
src/main.cpp     código do desktop
assets/          logo.png, firefox.png, font.ttf
third_party/     stb_truetype.h, stb_image.h (baixados, fora do git)
install.sh       dependências e downloads
run.sh           compila e executa
```

## Publicar no seu GitHub

Crie um repositório vazio `droidos` no github.com e rode:

```bash
cd ~/droidos
git remote add origin https://github.com/SEU_USUARIO/droidos.git
git push -u origin main
```

Na senha, use um **token de acesso pessoal** (GitHub → Settings → Developer settings → Personal access tokens).
