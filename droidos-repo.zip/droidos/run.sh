#!/usr/bin/env bash
# Compila (se o código mudou) e executa o DroidOS.
cd "$(dirname "$0")" || exit 1
export DROIDOS_DIR="$PWD"
export DISPLAY="${DISPLAY:-:0}"

# variáveis extras (GPU etc.): coloque em env.sh, por exemplo:  export GALLIUM_DRIVER=zink
if [ -f env.sh ]; then
  . ./env.sh
elif [ -f "$HOME/test_local/run_engine.sh" ]; then
  # reaproveita só os "export" do seu run_engine.sh antigo
  eval "$(grep -E '^[[:space:]]*export[[:space:]]' "$HOME/test_local/run_engine.sh")"
fi

[ -f third_party/stb_truetype.h ] && [ -f third_party/stb_image.h ] || ./install.sh
[ "$1" = "--rebuild" ] && rm -f build/droidos

# DROIDOS_START_X11=1 ./run.sh  -> também inicia o servidor termux-x11
if [ "$DROIDOS_START_X11" = "1" ] && command -v termux-x11 >/dev/null 2>&1; then
  termux-x11 "$DISPLAY" >/dev/null 2>&1 &
  sleep 2
fi

mkdir -p build
if [[ ! -f build/droidos || src/main.cpp -nt build/droidos ]]; then
  echo "==> Compilando..."
  g++ -O2 -w -I third_party src/main.cpp -o build/droidos -lX11 -lEGL -lGLESv2 || { echo "Erro na compilação."; exit 1; }
fi

exec ./build/droidos
